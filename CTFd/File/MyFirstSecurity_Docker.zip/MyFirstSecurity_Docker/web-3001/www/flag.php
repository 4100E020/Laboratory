<?php

$flag = "BreakALLCTF{fzfaD1jdXyQAMWvRShGC}";

