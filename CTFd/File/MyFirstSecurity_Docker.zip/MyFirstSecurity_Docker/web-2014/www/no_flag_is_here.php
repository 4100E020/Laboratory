<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BreakALLCTF</title>


    <link href="css/bootstrap.min.css" rel="stylesheet">


    <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>


    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">BreakALL CTF</a>
            </div>

        </div>

    </nav>


    <div class="container">

  
            <h2>BreakALL CTF</h2>

            </p>
      

        <hr>


        <div class="row">
            <div class="col-lg-12">
                <h4>你知道curl嗎?</h4>
            </div>
        </div>

        <div class="row text-center">

            <div class="col-sm-12 hero-feature">
                <div class="thumbnail">

                    <div class="caption">
                        <h3>這裡沒有flag哦!!</h3>
                        

                    </div>
                </div>
            </div>







        </div>


     




    </div>
	
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>
