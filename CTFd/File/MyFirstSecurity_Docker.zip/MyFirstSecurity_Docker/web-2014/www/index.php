BreakALLCTF{91YODwgPD58gpC4H9AeD}
<?php
header('Location: no_flag_is_here.php');
?>