#!/bin/bash
cd web-2001
docker build -t breakallwebctf-2017-02-web-1 .
docker run -p 2001:80 -d --restart=always breakallwebctf-2017-02-web-1
cd ../web-2006
docker build -t breakallwebctf-2017-02-web-1 .
docker run -p 2006:80 -d --restart=always breakallwebctf-2017-02-web-1
cd ../web-1001
docker build -t breakallctf-2017-01-web-1 .
docker run -p 1001:80 -d --restart=always breakallctf-2017-01-web-1
cd ../web-2014
docker build -t breakallwebctf-2017-02-web-4 .
docker run -p 2014:80 -d --restart=always breakallwebctf-2017-02-web-4
cd ../web-3001
docker build -t breakallwebctf_2017-03-web-1 .
docker run -p 3001:80 -d --restart=always breakallwebctf_2017-03-web-1
cd ../lab
docker build -t ubuntussh_lab .
docker run --network=bridge -p 2200:22 -d --restart=always ubuntussh_lab
docker run --network=bridge -p 5500:22 -d --restart=always ubuntussh_lab
